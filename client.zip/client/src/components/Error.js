 import React from 'react';
 
 function Error(props) {
    return (
        <div>
            <h1>Page Not Found</h1>
        </div>
    );
 }
 
 export default Error;