import React from 'react';

function Otp(props) {
    return (
        <div>
            <h1>OTP</h1>
        </div>
    );
}

export default Otp;