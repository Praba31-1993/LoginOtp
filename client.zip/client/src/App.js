import "./App.css";
import { Route, Routes, Navigate } from "react-router-dom";
import Header from "./components/Header";
import Register from "./components/Register";
import Login from "./components/Login";
import Error from "./components/Error";
import Otp from "./components/Otp";
import Dashboard from "./components/Dashboard";

function App() {
  return (
    <div className="App">
      <Header />
      <Routes>
        <Route path="/" element={<Navigate replace to="/register" />} />
        <Route path="register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/user/otp" element={<Otp />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="*" element={<Error />} />

      </Routes>
    </div>
  );
}

export default App;
